#import good.alpha as alpha
from good.best import sigma, tau

print(sigma.FunS())
print(tau.FunT())