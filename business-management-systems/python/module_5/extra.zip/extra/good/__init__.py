from good import alpha
from good import beta