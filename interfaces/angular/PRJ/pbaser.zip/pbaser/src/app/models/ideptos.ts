export interface Ideptos {
    id:string;
    name:string;
    jefe:string;
    horario:string;
    contacto:string;
    
}
