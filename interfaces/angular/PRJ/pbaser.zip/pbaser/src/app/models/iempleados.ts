export interface Iempleados {
    "id":number;
    "name":string;
    "username":string;
    "email":string;
    "depto":string;
    
}
